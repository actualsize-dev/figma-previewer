import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

type Project = {
  id: string;
  name: string;
  slug: string;
  figmaUrl: string;
  clientLabel?: string;
  createdAt: string;
};

export async function GET() {
  try {
    const projectsFile = path.join(process.cwd(), 'data', 'projects.json');
    
    if (!fs.existsSync(projectsFile)) {
      return NextResponse.json({ clients: [] });
    }
    
    const data = fs.readFileSync(projectsFile, 'utf8');
    const projects: Project[] = JSON.parse(data);
    
    // Extract unique client labels
    const clientLabels = new Set<string>();
    projects.forEach(project => {
      if (project.clientLabel && project.clientLabel !== 'Uncategorized') {
        clientLabels.add(project.clientLabel);
      }
    });
    
    // Convert to sorted array
    const clients = Array.from(clientLabels).sort();
    
    return NextResponse.json({ clients });
  } catch (error) {
    console.error('Error fetching client labels:', error);
    return NextResponse.json({ clients: [] });
  }
}