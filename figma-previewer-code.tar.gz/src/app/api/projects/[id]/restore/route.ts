import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

type Project = {
  id: string;
  name: string;
  slug: string;
  figmaUrl: string;
  createdAt: string;
};

type DeletedProject = Project & {
  deletedAt: string;
};

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const projectsFile = path.join(process.cwd(), 'data', 'projects.json');
    const deletedProjectsFile = path.join(process.cwd(), 'data', 'deleted-projects.json');

    if (!fs.existsSync(deletedProjectsFile)) {
      return NextResponse.json({ error: 'No deleted projects found' }, { status: 404 });
    }

    const deletedData = fs.readFileSync(deletedProjectsFile, 'utf8');
    const deletedProjects: DeletedProject[] = JSON.parse(deletedData);

    const projectIndex = deletedProjects.findIndex(project => project.id === id);
    
    if (projectIndex === -1) {
      return NextResponse.json({ error: 'Deleted project not found' }, { status: 404 });
    }

    // Get the project to restore
    const projectToRestore = deletedProjects[projectIndex];
    
    // Remove deletedAt timestamp
    const { deletedAt, ...restoredProject } = projectToRestore;

    // Check for slug conflicts
    let activeProjects = [];
    if (fs.existsSync(projectsFile)) {
      const activeData = fs.readFileSync(projectsFile, 'utf8');
      activeProjects = JSON.parse(activeData);
    }

    const slugExists = activeProjects.some((p: Project) => p.slug === restoredProject.slug);
    if (slugExists) {
      // Generate new slug with timestamp
      const timestamp = Date.now();
      restoredProject.slug = `${restoredProject.slug}-restored-${timestamp}`;
    }

    // Remove from deleted projects
    deletedProjects.splice(projectIndex, 1);

    // Add to active projects
    activeProjects.unshift(restoredProject); // Add to beginning

    // Write back to both files
    fs.writeFileSync(projectsFile, JSON.stringify(activeProjects, null, 2));
    fs.writeFileSync(deletedProjectsFile, JSON.stringify(deletedProjects, null, 2));

    return NextResponse.json({ 
      message: 'Project restored successfully',
      project: restoredProject 
    });
  } catch (error) {
    console.error('Error restoring project:', error);
    return NextResponse.json({ error: 'Failed to restore project' }, { status: 500 });
  }
}