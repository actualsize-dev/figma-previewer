import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

type Project = {
  id: string;
  name: string;
  slug: string;
  figmaUrl: string;
  createdAt: string;
};

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const projectsFile = path.join(process.cwd(), 'data', 'projects.json');
    const deletedProjectsFile = path.join(process.cwd(), 'data', 'deleted-projects.json');

    if (!fs.existsSync(projectsFile)) {
      return NextResponse.json({ error: 'Projects file not found' }, { status: 404 });
    }

    const data = fs.readFileSync(projectsFile, 'utf8');
    const projects: Project[] = JSON.parse(data);

    const projectIndex = projects.findIndex(project => project.id === id);
    
    if (projectIndex === -1) {
      return NextResponse.json({ error: 'Project not found' }, { status: 404 });
    }

    // Get the project to delete
    const projectToDelete = projects[projectIndex];
    
    // Add deletedAt timestamp
    const deletedProject = {
      ...projectToDelete,
      deletedAt: new Date().toISOString()
    };

    // Remove from active projects
    projects.splice(projectIndex, 1);

    // Add to deleted projects
    let deletedProjects = [];
    if (fs.existsSync(deletedProjectsFile)) {
      const deletedData = fs.readFileSync(deletedProjectsFile, 'utf8');
      deletedProjects = JSON.parse(deletedData);
    }
    deletedProjects.unshift(deletedProject); // Add to beginning

    // Write back to both files
    fs.writeFileSync(projectsFile, JSON.stringify(projects, null, 2));
    fs.writeFileSync(deletedProjectsFile, JSON.stringify(deletedProjects, null, 2));

    return NextResponse.json({ message: 'Project deleted successfully' });
  } catch (error) {
    console.error('Error deleting project:', error);
    return NextResponse.json({ error: 'Failed to delete project' }, { status: 500 });
  }
}