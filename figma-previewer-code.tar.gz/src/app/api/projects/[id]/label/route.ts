import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

type Project = {
  id: string;
  name: string;
  slug: string;
  figmaUrl: string;
  clientLabel?: string;
  createdAt: string;
};

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { clientLabel } = await request.json();
    const projectsFile = path.join(process.cwd(), 'data', 'projects.json');

    if (!fs.existsSync(projectsFile)) {
      return NextResponse.json({ error: 'Projects file not found' }, { status: 404 });
    }

    const data = fs.readFileSync(projectsFile, 'utf8');
    const projects: Project[] = JSON.parse(data);

    const projectIndex = projects.findIndex(project => project.id === id);
    
    if (projectIndex === -1) {
      return NextResponse.json({ error: 'Project not found' }, { status: 404 });
    }

    // Update the client label
    projects[projectIndex].clientLabel = clientLabel || 'Uncategorized';

    // Write back to file
    fs.writeFileSync(projectsFile, JSON.stringify(projects, null, 2));

    return NextResponse.json({ 
      message: 'Client label updated successfully',
      project: projects[projectIndex]
    });
  } catch (error) {
    console.error('Error updating client label:', error);
    return NextResponse.json({ error: 'Failed to update client label' }, { status: 500 });
  }
}